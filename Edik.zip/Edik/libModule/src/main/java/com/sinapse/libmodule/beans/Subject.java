package com.sinapse.libmodule.beans;

enum Subject {

}
