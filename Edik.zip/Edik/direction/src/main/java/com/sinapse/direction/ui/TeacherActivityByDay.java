package com.sinapse.direction.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.sinapse.direction.R;

public class TeacherActivityByDay extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_by_day);
    }
}
