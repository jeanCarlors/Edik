package com.sinapse.direction.ui;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sinapse.direction.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class EdikContentFragment extends Fragment {

    public EdikContentFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_edik_content, container, false);
    }
}
