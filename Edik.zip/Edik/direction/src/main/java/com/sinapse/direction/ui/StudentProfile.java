package com.sinapse.direction.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.sinapse.direction.R;

public class StudentProfile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_profile);
    }
}
