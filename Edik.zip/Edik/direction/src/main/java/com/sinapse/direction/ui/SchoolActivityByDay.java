package com.sinapse.direction.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.sinapse.direction.R;

public class SchoolActivityByDay extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_school_by_day);
    }
}
