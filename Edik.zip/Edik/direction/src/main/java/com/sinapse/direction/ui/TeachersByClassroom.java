package com.sinapse.direction.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.sinapse.direction.R;

public class TeachersByClassroom extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teachers_by_classroom);
    }
}
