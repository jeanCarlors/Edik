package com.sinapse.professeur.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.sinapse.professeur.R;

public class Classrooms extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classrooms);
    }
}
